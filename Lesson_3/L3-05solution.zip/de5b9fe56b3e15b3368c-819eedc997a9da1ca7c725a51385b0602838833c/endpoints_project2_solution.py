from flask import Flask, request
app = Flask(__name__) 

# Create the appropriate app.route functions, 
#test and see if they work


#Make an app.route() decorator here
@app.route("/puppies/", methods = ['GET', 'POST'])
def PuppiesFunction():
  if request.method == 'GET':
    #Call the method to Get all of the puppies
    return getAllPuppies()
  elif request.method == 'POST':
    #Call the method to make a new puppy
    return makeANewPuppy()
 
  
 
#Make another app.route() decorator here that takes in an integer id in the URI
@app.route("/puppies/<int:id>/", methods = ['GET', 'PUT', 'DELETE'])
def puppiesFunction(id):
  if request.method == 'GET':
    return getPuppy(id)
    
  #Call the method to view a specific puppy
  elif request.method == 'PUT':
    return updatePuppy(id)
    
 #Call the method to remove a puppy 
  elif request.method == 'DELETE':
    return deletePuppy(id)

def getAllPuppies():
  return "Getting All the puppies!"

def getPuppy(id):
  return "Getting information of puppy with id %s" % id 
  
def makeANewPuppy():
  return "Creating A New Puppy!"

def updatePuppy(id):
  return "Updating a Puppy with id %s" % id

def deletePuppy(id):
  return "Removing Puppy with id %s" % id


if __name__ == '__main__':
    app.debug = False 
    app.run(host='0.0.0.0', port=5000)	